/**
 * 平台接入封装
 * accessCode：访问接入授权码  【注：开发者请替换成自己的访问码】
 * serverUrl：平台接入服务端http协议接入地址【注：开发者请替换成自己搭建的平台http协议访问地址】
 * serverUrl_https：平台接入服务端https协议接入地址【注：开发者请替换成自己搭建的平台https协议访问地址】
 * init：SDK初始化
 * exec：SDK获取token，并执行回调方法同时传递token值
 */
var tokensdk = {
	"accessCode" : "63df8853-1060-4e43-bf4a-5f4be771543e",
	"serverUrl" : "http://172.16.0.36:8001",
	"serviceUrl" : "http://172.16.0.36:8001/ExMobiService",
	init : function() {
		//该方法为SDK初始化操作
		var jsonData = {};
		jsonData.accessCode = this.accessCode;
		AccessAuthUtil.init(jsonData);
	},
	exec : function (func) {
		//调用初始化
		if (!this.isinit) {
			this.init();
			this.isinit = true;
		}   
		//获取访问码，调用回调方法
		var jsonData = {};
		jsonData.url = this.serverUrl + "/api/getAccessToken";
		AccessAuthUtil.getToken(jsonData, func);
	}
};