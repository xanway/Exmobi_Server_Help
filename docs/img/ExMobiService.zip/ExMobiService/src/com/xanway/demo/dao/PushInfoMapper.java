package com.xanway.demo.dao;

import com.xanway.demo.entity.PushInfo;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PushInfoMapper {
    int deleteByPrimaryKey(String pushId);

    int insert(PushInfo record);

    int insertOrUpdate(PushInfo record);

    int insertOrUpdateSelective(PushInfo record);

    int insertSelective(PushInfo record);

    PushInfo selectByPrimaryKey(String pushId);

    int updateByPrimaryKeySelective(PushInfo record);

    int updateByPrimaryKey(PushInfo record);

    int updateBatch(List<PushInfo> list);

    int batchInsert(@Param("list") List<PushInfo> list);
}