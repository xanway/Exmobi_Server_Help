package com.xanway.demo.controller.preview;

import com.alibaba.fastjson.JSONObject;
import com.xanway.business.paramconfig.ParamConfig;
import com.xanway.http.bean.HttpResponseBean;
import com.xanway.http.impl.HttpUtil;
import com.xanway.preview.FileToImage;
import com.xanway.preview.bean.DocConvertParam;
import com.xanway.preview.bean.FilePreviewResult;

import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * @classname: PreviewController
 * @author: xw41
 * @date: 2019/11/21 14:03
 * @description:  调用Exmobi的dcs进行文档转换成图片
 */
@Controller
public class PreviewController {

    /**
     * 文件预览
     * @param pageNum 预览的页数
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/demo/doPreview")
    public Object doPreview(@RequestParam(required = false, value = "pageNum") Integer pageNum) {
        String dcsAddress = ParamConfig.getValue("dcsServer");
        FileToImage fileToImage = new FileToImage(dcsAddress);
        FilePreviewResult result = null;
        DocConvertParam docConvertParam = new DocConvertParam();
        if (null != pageNum) {
            docConvertParam.setPageNum(pageNum);
        } else {
            docConvertParam.setPageNum(1);
        }
        docConvertParam.setSrcFileExt("doc");
        HttpUtil httpUtil = new HttpUtil();
        String url = null;
        try {
            url = URLEncoder.encode("http://172.16.0.102/samba/test/titan/通用扩展查询，全文检索查询接口说明.doc", "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        HttpResponseBean rsp = httpUtil.sendGet(url);
        InputStream is = null;
        try {
            is = rsp.getResponseFileInputStream();
            result = fileToImage.convertToJpg(is, docConvertParam);
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            IOUtils.closeQuietly(is);
        }
        //文档转为图片
        String convertResult = result.getResult();//获取转换结果
        String convertMsg = result.getMsg();//获取转换结果描述信息
        String convertIdentifier = result.getConvertIdentifier();//获取文档转换唯一标识
        String fileMd5 = result.getFileMd5();//获取源文档md5值
        int totalPageNum = result.getTotalPageNum();//获取文档总页数
        int currentPageNum = result.getCurrentPageNum();//获取当前预览页数
        String imgBase64Str = null;
        try {
            imgBase64Str = fileToImage.getPageBase64(result);
        } catch (Exception e) {
            e.printStackTrace();
        }
        JSONObject rspJson = new JSONObject();
        rspJson.put("convertMsg", convertMsg);
        rspJson.put("convertIdentifier", convertIdentifier);
        rspJson.put("fileMd5", fileMd5);
        rspJson.put("totalPageNum", totalPageNum);
        rspJson.put("currentPageNum", currentPageNum);
        rspJson.put("imgBase64Str", imgBase64Str);
        return rspJson;
    }
}
