package com.xanway.demo.controller.push;

import com.alibaba.fastjson.JSONObject;
import com.xanway.business.paramconfig.ParamConfig;
import com.xanway.push.PnsPushManager;
import com.xanway.push.bean.GetPushStatusRequest;
import com.xanway.push.bean.GetPushStatusResponse;
import com.xanway.push.bean.PushMessageRequest;
import com.xanway.push.bean.PushMessageResponse;
import com.xanway.demo.entity.PushInfo;
import com.xanway.demo.service.PushInfoService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;

/**
 * @classname: PushController
 * @author: xw41
 * @date: 2019/11/21 14:03
 * @description: 调用Exmobi的推送服务
 */
@Controller
public class PushController {

    private static final Logger logger = LoggerFactory.getLogger(PushController.class);

    @Resource
    private PushInfoService pushInfoService;

    /**
     * @param sender 发送方
     * @param esn    推送的客户端esn
     */
    @RequestMapping(value = "/demo/sendPush")
    @ResponseBody
    public Object sendPush(@RequestParam(required = false, value = "sender") String sender, @RequestParam(required = false, value = "esn") String esn) throws Exception {

        PushMessageRequest pushRequestBean = new PushMessageRequest();
        PnsPushManager pnsPushManager = new PnsPushManager();
        List<String> destAddr = new ArrayList<>();

        destAddr.add(esn == null ? "esn:247189141280922" : "esn:" + esn);
        pnsPushManager.setPnsServiceUrl(ParamConfig.getValue("pnsServer"));
        pushRequestBean.setApplicationId("gaeaclient-android-000004");
        pushRequestBean.setCheckkey("bcs");
        pushRequestBean.setDestAddr(destAddr);
        String msgContent = "{\"titlehead\": \"标题\",\"title\": \"推送消息\",\"page\":\"\"}";
        pushRequestBean.setMsgContent(msgContent);
        pushRequestBean.setTitle("您有新消息");
        pushRequestBean.setType("app");
        String toServerResult = "";
        String toClientResult = "";
        try {
            PushMessageResponse pushMessageResponse = pnsPushManager.pushMessage(pushRequestBean);
            if (null != pushMessageResponse) {
                toServerResult = pushMessageResponse.getResult() + "=======" + pushMessageResponse.getMsg();
            }
            try {
                Thread.sleep(2000);
                GetPushStatusRequest getPushStatusRequestBean = new GetPushStatusRequest();
                // 设置推送标识
                getPushStatusRequestBean.setRequestIdentifier(pushMessageResponse.getRequestIdentifier());
                // 获取推送结果
                GetPushStatusResponse getPushStatusResponseBean = pnsPushManager.getPushStatus(getPushStatusRequestBean);
                toClientResult = getPushStatusResponseBean.getDeliveryStatusList().toString();
                //将推送信息存入mysql数据库
                PushInfo pushInfo = new PushInfo();
                pushInfo.setSender(sender);
                pushInfo.setPushId(UUID.randomUUID().toString());
                pushInfo.setApplicationId("gaeaclient-android-000004");
                pushInfo.setCreatetime(new Date());
                pushInfo.setDestaddr(destAddr.get(0));
                pushInfo.setMsgcontent(msgContent);
//                pushInfo.setPushstatus(getPushStatusResponseBean.getDeliveryStatusList().get(0).getResult());
                pushInfoService.insert(pushInfo);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        JSONObject json = new JSONObject();
        json.put("result", "success");
        json.put("toServerResult", toServerResult);
        json.put("toClientResult", toClientResult);
        return json;
    }
}
