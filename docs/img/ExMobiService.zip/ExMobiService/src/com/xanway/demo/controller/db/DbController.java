package com.xanway.demo.controller.db;

import com.alibaba.fastjson.JSONObject;
import com.xanway.db.impl.DBProcessImpl;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.UUID;

import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 * @classname: DbController
 * @author: xw41
 * @date: 2019/11/21 14:18
 * @description:  数据库操作
 */
@Controller
public class DbController {


    @Resource(name = "dataSource")
    private DataSource ds;

    /**
     * 数据库操作
     * @param id
     * @param name
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/demo/saveUser")
    @ResponseBody
    public Object saveUser(@RequestParam(required = true, value = "id") String id, @RequestParam(required = true, value = "name") String name) throws Exception {
        DBProcessImpl aaa = new DBProcessImpl(ds);
        int insertResult = 0;
        String insertSql = "insert into tbl_user_info (id,name) values (?,?)";
        insertResult = aaa.update(insertSql, new Object[]{id, name});
        JSONObject json = new JSONObject();
        json.put("result", insertResult);
        return json;
    }
}
