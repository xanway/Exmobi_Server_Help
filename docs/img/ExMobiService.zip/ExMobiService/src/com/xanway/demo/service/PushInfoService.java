package com.xanway.demo.service;

import com.xanway.demo.entity.PushInfo;
import java.util.List;

public interface PushInfoService {


    int deleteByPrimaryKey(String pushId);

    int insert(PushInfo record);

    int insertOrUpdate(PushInfo record);

    int insertOrUpdateSelective(PushInfo record);

    int insertSelective(PushInfo record);

    PushInfo selectByPrimaryKey(String pushId);

    int updateByPrimaryKeySelective(PushInfo record);

    int updateByPrimaryKey(PushInfo record);

    int updateBatch(List<PushInfo> list);

    int batchInsert(List<PushInfo> list);

}


