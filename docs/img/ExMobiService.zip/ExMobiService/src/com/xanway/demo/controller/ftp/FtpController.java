package com.xanway.demo.controller.ftp;

import com.alibaba.fastjson.JSONObject;
import com.xanway.ftp.IFtpCommunication;
import com.xanway.ftp.bean.FtpFileDataBean;
import com.xanway.ftp.bean.FtpWorkingContextBean;
import com.xanway.ftp.impl.DefaultFtpCommunicationImpl;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @classname: FtpController
 * @author: xw41
 * @date: 2019/11/21 14:09
 * @description:
 */
@Controller
public class FtpController {

    @ResponseBody
    @RequestMapping(value = "/demo/ftpDownload")
    public Object ftpDownload() throws Exception {
        FtpWorkingContextBean ftpWorkingContextBean = new FtpWorkingContextBean();
        //FTP服务器地址,端口,用户名,密码
        ftpWorkingContextBean.setIp("172.16.2.23");
        ftpWorkingContextBean.setPort(21);
        ftpWorkingContextBean.setUsername("ftpuser");
        ftpWorkingContextBean.setPassword("qazwsxedc");
        System.err.println(ftpWorkingContextBean);
        IFtpCommunication ftpCommunication = new DefaultFtpCommunicationImpl(ftpWorkingContextBean);
        //要下载的文件所在的目录
        ftpCommunication.setWorkingDirectory("/home/ftpuser/");
        ftpCommunication.setFtpWorkingContextBean(ftpWorkingContextBean);
        FtpFileDataBean ftpFileDataBean = ftpCommunication.download("aa.xlsx");
        JSONObject rspJson = new JSONObject();
        rspJson.put("path", ftpFileDataBean.getDataFilePath());
        return rspJson;
    }

}
