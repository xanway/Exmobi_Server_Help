package com.xanway.demo.controller.login;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.xanway.business.paramconfig.ParamConfig;
import com.xanway.common.suport.xpath.CachedDom4jXpathProcessImpl;
import com.xanway.common.suport.xpath.IXPathProcess;
import com.xanway.common.util.XmlUtil;
import com.xanway.http.bean.FormParamter;
import com.xanway.http.bean.HttpContext;
import com.xanway.http.bean.HttpHeader;
import com.xanway.http.bean.HttpRequestBean;
import com.xanway.http.bean.HttpResponseBean;
import com.xanway.http.impl.HttpUtil;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

/**
 * @classname: PathController
 * @author: xw41
 * @date: 2019/11/21 13:23
 * @description:
 */
@Controller
public class LoginController {

    private static final Logger logger = Logger.getLogger(LoginController.class);

    /**
     * 先登陆edn平台再获取登陆用户中心页面显示的个人信息
     * @param session
     * @param username 用户名
     * @param pwd   密码
     * @return  json格式数据
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("/demo/login")
    public Object login(final HttpSession session, @RequestParam(required = false, value = "username") String username, @RequestParam(required = false, value = "pwd") String pwd) throws Exception {
        //初始构建上下文
        final HttpContext httpContext = new HttpContext();
        httpContext.setContextId(session.getId());
        HttpUtil httpUtil = new HttpUtil(httpContext);
        HttpRequestBean req = new HttpRequestBean();
        //设置url 从config.xml文件中读取 paraKey为 exmobiLogin 的值
        String url = ParamConfig.getValue("exmobiLogin");
        req.setUrl(url);
        req.setEnctype(1);
        //设置请求头
        List<HttpHeader> headers = new ArrayList<HttpHeader>();
        headers.add(new HttpHeader("Content-Type", "application/x-www-form-urlencoded"));
        req.setHeaders(headers);
        //设置Method
        req.setMethod("POST");
        //设置请求参数
        List<FormParamter> params = new ArrayList<FormParamter>();
        params.add(new FormParamter("username", username));
        params.add(new FormParamter("password", pwd));
        req.setFormParams(params);
        //发起请求
        HttpResponseBean rsp = httpUtil.sendHttpRequest(req);
        // 获取响应吗
        int status = rsp.getStatusCode();
        JSONArray articlesArray = new JSONArray();
        if (status == 200) {
            HttpUtil DetailHttpUtil = new HttpUtil(httpContext);
            String detailUrl = ParamConfig.getValue("personalInfo");
            HttpResponseBean detailRsp = DetailHttpUtil.sendGet(detailUrl);
            int detailStatus = detailRsp.getStatusCode();
            if (detailStatus == 200) {
                Document dom = XmlUtil.html2xml(detailRsp.getResponseBody("UTF-8"));
                IXPathProcess ixp = new CachedDom4jXpathProcessImpl();
                JSONObject article = new JSONObject();
                article.put("accountName", ixp.selectNodeValue("//input[@name='account_name']/@value", dom));
                article.put("email", ixp.selectNodeValue("//input[@name='account_spare2']/@value", dom));
                article.put("tel", ixp.selectNodeValue("//input[@name='account_spare1']/@value", dom));
                article.put("trueName", ixp.selectNodeValue("//input[@name='account_name_cn']/@value", dom));
                articlesArray.add(article);
            }
        }
        JSONObject rspJson = new JSONObject();
        rspJson.put("status", status);
        rspJson.put("articles", articlesArray);
        logger.info(rspJson);
        return rspJson;
    }
}
