package com.xanway.demo.service.impl;

import com.xanway.demo.dao.PushInfoMapper;
import com.xanway.demo.entity.PushInfo;
import com.xanway.demo.service.PushInfoService;

import org.springframework.stereotype.Service;

import java.util.List;

import javax.annotation.Resource;

@Service
public class PushInfoServiceImpl implements PushInfoService {

    @Resource
    private PushInfoMapper pushInfoMapper;

    @Override
    public int deleteByPrimaryKey(String pushId) {
        return pushInfoMapper.deleteByPrimaryKey(pushId);
    }

    @Override
    public int insert(PushInfo record) {
        return pushInfoMapper.insert(record);
    }

    @Override
    public int insertOrUpdate(PushInfo record) {
        return pushInfoMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(PushInfo record) {
        return pushInfoMapper.insertOrUpdateSelective(record);
    }

    @Override
    public int insertSelective(PushInfo record) {
        return pushInfoMapper.insertSelective(record);
    }

    @Override
    public PushInfo selectByPrimaryKey(String pushId) {
        return pushInfoMapper.selectByPrimaryKey(pushId);
    }

    @Override
    public int updateByPrimaryKeySelective(PushInfo record) {
        return pushInfoMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public int updateByPrimaryKey(PushInfo record) {
        return pushInfoMapper.updateByPrimaryKey(record);
    }

    @Override
    public int updateBatch(List<PushInfo> list) {
        return pushInfoMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<PushInfo> list) {
        return pushInfoMapper.batchInsert(list);
    }

}


